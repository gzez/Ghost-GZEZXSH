# Optica Theme for Ghost
Optica 原来是一款 Typecho 主题，它被我移植到了 Ghost 上。

[原主题详情](http://imikirby.com/83.html)

### Ghost 版特点 ###
* 适用于 Ghost 博客平台
* 完善的 PJAX
……

### Ghost 0.7 及以上版本用户注意 ###

由于新版 Ghost 不再嵌入 jQuery，请务必自行在后台设置的 Code Injection 中的底部代码一栏手工引入 jQuery 库，否则本主题将不会正常工作！

欢迎提交代码。
